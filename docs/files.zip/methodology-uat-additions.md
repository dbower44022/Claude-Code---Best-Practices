# Methodology Guide Additions for UAT

These are the proposed additions to `prd-methodology-guide.md` for the next version bump.

---

## Addition 1: New Document Type Section

> Insert as new Section 2.X after the existing document types (Entity Base PRD, Entity UI PRD, Action Sub-PRD, TDD, Functional Area PRD).

### 2.X User Acceptance Testing (UAT) Guide

**Purpose:** Verifies that the implementation satisfies every requirement defined in the source PRDs and every testable decision in the source TDDs. UAT guides close the gap between developer-generated tests (which tend toward structural code coverage) and requirement-level verification (which confirms that specified features actually work as designed).

**When to create:** After the source PRD and TDD are stable, before Claude Code begins implementation. This gives Claude Code explicit acceptance criteria to code against, not just requirements to interpret.

**Required for:**
- Entity Base PRDs
- Action Sub-PRDs
- Functional Area PRDs

**Not required for:**
- Product PRD (architectural/philosophical, not feature-specific)
- GUI Standards (visual conventions, not testable requirements)
- Product TDD (global decisions are verified through the entity/action UAT guides that depend on them)

**Naming convention:** Mirrors the PRD it covers. `contact-identity-resolution-prd.md` → `contact-identity-resolution-uat.md`. Entity Base PRDs: `contact-entity-base-uat.md`.

**File location:** Same directory as the PRD it covers (`PRDs/`), not a subdirectory.

**Key principle — complete traceability:** Every requirement ID in the source PRD and every testable TDD decision must appear at least once in the UAT Traceability Matrix. A requirement without a UAT test is a coverage gap. The UAT guide makes these gaps visible rather than letting them surface after implementation.

**Scope rules:**
- TDD decisions are covered in the UAT guide for the PRD they support — not in a separate TDD-level UAT. For example, a Contact Entity TDD decision about † cached sort field pre-computation is tested in the `contact-entity-base-uat.md` alongside the PRD requirements it enables.
- Cross-cutting verifications test integration boundaries between this functional area and others. These live in the UAT guide for the functional area initiating the interaction.

**Template:** `Templates/template-uat.md`

---

## Addition 2: Template Registry Update

> Add this row to the Template Registry table in Section 3.

| Template File | Document Type | Level |
|---|---|---|
| `template-uat.md` | User Acceptance Testing Guide | Entity / Action / Functional Area |

---

## Addition 3: Changelog Entry

> Add to the version history at the top of the document.

> **V5.0 ([DATE]):** Added User Acceptance Testing (UAT) Guide as a new document type (Section 2.X) with template. UAT guides provide requirement-level traceability for Entity Base PRDs, Action Sub-PRDs, and Functional Area PRDs.
